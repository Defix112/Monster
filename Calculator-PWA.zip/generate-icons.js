// Скрипт для генерации иконок PWA
// Запустите: node generate-icons.js
// Требуется: npm install canvas (или используйте create-icons.html в браузере)

const fs = require('fs');
const { createCanvas } = require('canvas');

function createIcon(size, filename) {
    const canvas = createCanvas(size, size);
    const ctx = canvas.getContext('2d');
    
    // Фон с градиентом
    const gradient = ctx.createLinearGradient(0, 0, size, size);
    gradient.addColorStop(0, '#667eea');
    gradient.addColorStop(1, '#764ba2');
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, size, size);
    
    // Белый прямоугольник (калькулятор)
    ctx.fillStyle = 'white';
    const padding = size * 0.15;
    const calcWidth = size - padding * 2;
    const calcHeight = size - padding * 2;
    ctx.fillRect(padding, padding, calcWidth, calcHeight);
    
    // Экран калькулятора
    ctx.fillStyle = '#1a1a1a';
    const screenPadding = size * 0.2;
    const screenWidth = calcWidth - (screenPadding - padding) * 2;
    const screenHeight = size * 0.15;
    ctx.fillRect(screenPadding, screenPadding, screenWidth, screenHeight);
    
    // Кнопки
    ctx.fillStyle = '#667eea';
    const buttonSize = size * 0.08;
    const buttonSpacing = size * 0.12;
    const startY = size * 0.5;
    const startX = size * 0.3;
    
    for (let row = 0; row < 3; row++) {
        for (let col = 0; col < 3; col++) {
            ctx.beginPath();
            ctx.arc(
                startX + col * buttonSpacing,
                startY + row * buttonSpacing,
                buttonSize / 2,
                0,
                Math.PI * 2
            );
            ctx.fill();
        }
    }
    
    // Сохранение
    const buffer = canvas.toBuffer('image/png');
    fs.writeFileSync(filename, buffer);
    console.log(`Иконка создана: ${filename} (${size}x${size})`);
}

// Создание иконок
try {
    createIcon(192, 'icon-192.png');
    createIcon(512, 'icon-512.png');
    console.log('Все иконки успешно созданы!');
} catch (error) {
    console.log('Ошибка: Для работы скрипта требуется библиотека canvas.');
    console.log('Установите: npm install canvas');
    console.log('Или используйте create-icons.html в браузере для создания иконок.');
}

